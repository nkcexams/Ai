import pandas as pd
from apyori import apriori

data=pd.read_csv('store_data.csv',header=None)
records=data.astype(str).values.tolist()

association_rules=apriori(records,min_support=0.0045,min_confidence=0.2,min_lift=3,
                          min_length=2)
association_result=list(association_rules)

print(len(association_result))
print(association_result)
