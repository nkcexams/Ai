import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans


data= pd.read_csv(r'C:\Users\purav\OneDrive\Desktop\Sem VI\DS\Countryclusters.csv')
print(data)

plt.scatter(data['Longitude'],data['Latitude'])
plt.xlim(-180,180)
plt.ylim(-90,90)
plt.show()

kmeans=KMeans(n_clusters=3,n_init=10,random_state=42)
data['Clusters']=kmeans.fit_predict(data.iloc[:,1:3])
print(data['Clusters'])

plt.scatter(data['Longitude'],data['Latitude'],c=data['Clusters'],cmap='rainbow')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('clusters of countries')
plt.show()