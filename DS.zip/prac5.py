import numpy as np
from sklearn.decomposition import PCA

x = np.array([[-1, -1], [-2, -1], [-3, -2], [1, 1], [2, 1], [3, 2]])
solvers=[('auto',2),('full',2),('arpack',1)]

for solver,n in solvers:
    pca=PCA(n_components=n,svd_solver=solver)
    pca.fit(x)
    print(solver)
    print(pca.explained_variance_ratio_)
    print(pca.singular_values_)
