import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix

df= pd.read_csv(r'C:\Users\purav\OneDrive\Desktop\Sem VI\DS\Admission_Data.csv')
print(df)

X=df[[ 'gmat', 'gpa', 'work_experience' ]]
y = df['admitted']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
l_r = LogisticRegression().fit(X_train, y_train)
y_pred=l_r.predict(X_test)

print(f'Accuracy: {accuracy_score(y_test,y_pred)*100:.2f}')
print(confusion_matrix(y_pred,y_test))
