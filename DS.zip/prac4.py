import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df= pd.read_csv(r"C:\Users\purav\OneDrive\Desktop\Sem VI\DS\AirPassengers.csv")
print(df.head())
print(df.tail())

df['Month'] = pd.to_datetime(df['Month'], format= '%Y-%m')
print(df.head())

df.index = df['Month']
print(df.head())

may_flights = df.query("Month =='1951-08'")
print(may_flights)

sns.lineplot(data=may_flights, x=may_flights.index,y='#Passengers')
plt.show()

sns.lineplot(data=df,x=df.index,y='#Passengers')
plt.show()