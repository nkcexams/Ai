import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv(r'C:\Users\purav\OneDrive\Desktop\Sem VI\DS\Salary_Data.csv')
x, y = df['YearsExperience'], df['Salary']

b1 = np.cov(x, y, bias=True)[0, 1] / np.var(x)
b0, r = y.mean() - b1 * x.mean(), np.corrcoef(x, y)[0, 1]

print(f"y = {b0:.3f} + {b1:.3f}X\nR: {r:.4f} | R²: {r**2:.4f}\nPredicted Salary (55 yrs): ${b0 + b1 * 55:.2f}")

plt.scatter(x, y)
plt.plot(x, b0 + b1 * x, 'r', lw=2, alpha=0.7)
plt.xlabel('Years of Experience')
plt.ylabel('Salary')
plt.title('Experience vs Salary')
plt.show()




