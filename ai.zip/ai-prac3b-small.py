from math import inf
class Node:
    def __init__(self,value,children=None):
        self.value=value
        self.children = children or []

    def get_children(self):
        return self.children

def hill_climbing(start_node):
    current_node= start_node

    while True:
        next_node=max(current_node.get_children(),key=lambda n: n.value,default=None)
        if not next_node or next_node.value <= current_node.value:
            return current_node
        current_node = next_node


nodeG = Node(3)
nodeF = Node(4)

nodeE = Node(7, [nodeF, nodeG])
nodeD = Node(6)
nodeC = Node(8, [nodeE, nodeF])
nodeB = Node(5, [nodeC, nodeD])
start_node = Node(2, [nodeB, nodeC])

result = hill_climbing(start_node)
print(f"best node value:{result.value}")
