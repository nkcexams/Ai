import networkx as nx

try:
    G=nx.read_graphml(r"newyork.graphml")
except Exception as e:
    print(f"error loading the graph:{e}")
    exit()

print(f"density:{nx.density(G):.4f}")
print("\n Degree (first 5 nodes):",dict(list(G.degree())[:5]))

if G.is_directed():
    print(f"\n reciprocity:{nx.reciprocity(G):.4f}")
else:
    print("\n reciprocity not applicable on undirected graph")

print(f" transitivity: {nx.transitivity(G):.4f}")

print("\n centrality (first 5 nodes):",dict(list(nx.degree_centrality(G).items())[:5]))
print("\n clustering (first 5 nodes):",dict(list(nx.degree_clustering(G).items())[:5]))

