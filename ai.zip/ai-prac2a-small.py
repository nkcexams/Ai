import networkx as nx
import matplotlib.pyplot as plt
import heapq

def greedy_bfs(graph,heuristics,start,goal):
    pq,visited=[(heuristics[start],start)],[]
    while pq:
        _,current=heapq.heappop(pq)
        if current == goal:
            visited.append(current)
            return visited
        if current not in visited:
            visited.append(current)
            for neighbor in graph.neighbors(current):
                heapq.heappush(pq,(heuristics[neighbor],neighbor))
    return visited

G=nx.DiGraph()
G.add_edges_from([('A', 'B'), ('A', 'C'), ('B', 'D'), ('B', 'E'), ('C', 'F'),
                  ('C', 'G'), ('D', 'H'), ('E', 'H'), ('F', 'H'), ('G', 'H')])
heuristics= {'A':13,'B': 12, 'C': 4, 'D': 7, 'E': 3, 'F': 8, 'G': 2, 'H': 0}

print("heuristics")
for node,h in heuristics.items():
    print(f"{node}:{h}")

path = greedy_bfs(G,heuristics,'A','H')
print("\n path found:")
print("->".join(path))

pos=nx.spring_layout(G)
nx.draw(G,pos,with_labels=True, node_color='lightblue',font_weight='bold',
        node_size=3000,arrowsize=20)
plt.show()
