import networkx as nx
import matplotlib.pyplot as plt

def ida_star(graph,heuristics,start,goal):
    def dfs(current,g,threshold,path):
        
        f= g+heuristics[current]
        if f > threshold:
            return f
        if current == goal:
            path.append(current)
            return 'found'
        min_cost = float('inf')
        for neighbor in graph.neighbors(current):
            if neighbor not in path:
                result = dfs(neighbor,g + 1,threshold,path +[current])
                if result == 'found':
                    return 'found'
                min_cost = min(min_cost,result)
        return min_cost
    threshold = heuristics[start]
    while True:
        path=[]
        result = dfs(start,0,threshold,path)
        if result == 'found':
            return path
        elif result == float('inf'):
            return None
        threshold = result
        
G = nx.DiGraph()
G.add_edges_from([('A', 'B'), ('A', 'C'), ('B', 'D'), ('B', 'E'),
         ('C', 'F'), ('C', 'G'), ('D', 'H'), ('E', 'H'),
         ('F', 'H'), ('G', 'H')])
heuristics={'A': 13, 'B': 12, 'C': 4, 'D': 7,
              'E': 3, 'F': 8, 'G': 2, 'H': 0}
print("heuristics")
for node,h in heuristics.items():
    print(f"{node}: {h}")

path = ida_star(G,heuristics,'A','H')
print("\n path found")
print("->".join(path))

pos={'A':(0,3),
     'B':(-1,2),'C':(1,2),
     'D':(-1.5,1),'E':(-0.5,1),'F':(0.5,1),'G':(1.5,1),
     'H':(0,0)
     }

nx.draw(G,pos,with_labels=True, node_color='lightblue',font_weight='bold',
        node_size=3000,arrowsize=20)
plt.show()
