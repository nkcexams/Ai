
import numpy as np
import h5py
import tensorflow as tf
from tensorflow.keras import layers, models

def load_data():
    train = h5py.File('train_catvnoncat.h5', "r")
    test = h5py.File('test_catvnoncat.h5', "r")
    x_train = np.array(train["train_set_x"]) / 255.0
    y_train = np.array(train["train_set_y"]).reshape(-1, 1)
    x_test = np.array(test["test_set_x"]) / 255.0
    y_test = np.array(test["test_set_y"]).reshape(-1, 1)
    return x_train, y_train, x_test, y_test

def build_model(input_shape):
    model = models.Sequential([
        layers.Conv2D(32, (3, 3), activation='relu', input_shape=input_shape),
        layers.MaxPool2D((2, 2)),
        layers.Flatten(),
        layers.Dense(64, activation='relu'),
        layers.Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['acc'])
    return model

if __name__ == "__main__":
    x_train, y_train, x_test, y_test = load_data()
    model = build_model(x_train.shape[1:])
    model.fit(x_train, y_train, epochs=5, batch_size=32, validation_data=(x_test, y_test))
    loss, acc = model.evaluate(x_test, y_test)
    print(f"Test acc: {acc * 100:.2f}%")
