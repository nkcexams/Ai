import heapq
import collections

romania_map={ 'Arad': {'Zerind': 75, 'Sibiu': 140, 'Timisoara': 118},
    'Bucharest': {'Giurgiu': 90, 'Fagaras': 211, 'Pitesti': 101, 'Urziceni': 85},
    'Craiova': {'Drobeta': 120, 'Pitesti': 138, 'Rimnicu Vilcea': 146},
    'Drobeta': {'Mehadia': 75, 'Craiova': 120},
    'Eforie': {'Urziceni': 86},
    'Fagaras': {'Bucharest': 211, 'Sibiu': 99},
    'Giurgiu': {'Bucharest': 90},
    'Hirsova': {'Urziceni': 98, 'Eforie': 86},
    'Iasi': {'Vaslui': 92, 'Neamt': 87},
    'Lugoj': {'Mehadia': 70, 'Timisoara': 111},
    'Mehadia': {'Drobeta': 75, 'Lugoj': 70},
    'Neamt': {'Iasi': 87},
    'Oradea': {'Zerind': 71, 'Sibiu': 151},
    'Pitesti': {'Bucharest': 101, 'Craiova': 138, 'Rimnicu Vilcea': 97},
    'Rimnicu Vilcea': {'Craiova': 146, 'Pitesti': 97, 'Sibiu': 80},
    'Sibiu': {'Arad': 140, 'Fagaras': 99, 'Rimnicu Vilcea': 80},
    'Timisoara': {'Arad': 118, 'Lugoj': 111},
    'Urziceni': {'Bucharest': 85, 'Hirsova': 98, 'Eforie': 86},
    'Vaslui': {'Iasi': 92},
    'Zerind': {'Arad': 75, 'Oradea': 71}
}

def bfs(graph,start,goal):
    queue=collections.deque([(start,[start])])
    visited=set()
    while queue:
        node,path=queue.popleft()
        if node == goal:
            return path
        if node not in visited:
            visited.add(node)
            for neighbor in graph[node]:
                if neighbor not in visited:
                    queue.append((neighbor,path + [neighbor]))
    return None

def dfs(graph,start,goal):
    stack=[(start,[start])]
    visited=set()
    while stack:
        node,path=stack.pop()
        if node==goal:
            return path
        if node not in visited:
            visited.add(node)
            for neighbor in graph[node]:
                if neighbor not in visited:
                    stack.append((neighbor,path +[neighbor]))
    return None
def dls(graph,start,goal,limit):
    stack=[(start,[start],0)]
    visited=set()
    while stack:
        node,path,depth=stack.pop()
        if node== goal:
            return path
        if depth < limit:
            visited.add(node)
            for neighbor in graph[node]:
                if neighbor not in visited:
                    stack.append((neighbor,path +[neighbor],depth+1))
    return None
start_node='Arad'
goal_node='Bucharest'
print("bfs:",bfs(romania_map,start_node,goal_node))
print("dfs:",dfs(romania_map,start_node,goal_node))
print("dls:",dls(romania_map,start_node,goal_node,limit=5))

