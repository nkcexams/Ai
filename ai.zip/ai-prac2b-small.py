import networkx as nx
import matplotlib.pyplot as plt
import heapq
def a_star_search(graph,heuristics,start,goal):
       open_list=[(heuristics[start],start)]
       g_cost={start:0}
       parents={start:None}

       while open_list:
           _,current=heapq.heappop(open_list)
           if current==goal:
               path=[]
               while current:
                   path.append(current)
                   current=parents[current]
               return path[::-1]

           for neighbor in graph.neighbors(current):
                new_cost=g_cost[current]+1
                if neighbor not in g_cost or new_cost < g_cost[neighbor]:
                    g_cost[neighbor]= new_cost
                    heapq.heappush(open_list,(new_cost + heuristics[neighbor],neighbor))
                    parents[neighbor] = current
       return[]
G = nx.DiGraph()
G.add_edges_from([('A', 'B'), ('A', 'C'), ('B', 'D'), ('B', 'E'),
                  ('C', 'F'), ('C', 'G'), ('D', 'H'), ('E', 'H'),
                  ('F', 'H'), ('G', 'H')])
heuristics={'A': 13, 'B': 12, 'C': 4, 'D': 7, 'E': 3, 'F': 8, 'G': 2, 'H': 0}
print("heuristics")
for node,h in heuristics.items():
    print(f"{node}:{h}")                
path=a_star_search(G,heuristics,'A','H')
print("\n path found")
print("->".join(path))
pos={
    'A':(0,3),
    'B':(-1,2),'C':(1,2),
    'D':(-1.5,1),'E':(-0.5,1),'F':(0.5,1),'G':(1.5,1),
    'H':(0,0)
    }
nx.draw(G,pos,with_labels=True,node_color='lightblue',font_weight='bold',
        node_size=3000,arrowsize=20)
plt.show()
