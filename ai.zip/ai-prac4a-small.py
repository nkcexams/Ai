import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense
from keras.optimizers import Adam

data=pd.read_csv("iris.csv")
print(data.head())

sns.pairplot(data,hue="Species")
plt.show()

X=data.iloc[:,1:5].values
y=pd.get_dummies(LabelEncoder().fit_transform(data.iloc[:,5].values)).values

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=0)

model = Sequential([
        Dense(40, input_shape=(4,),activation='relu'),
        Dense(20,activation='relu'),
        Dense(3,activation='softmax')
    ])

model.compile(optimizer=Adam(learning_rate=0.02),loss='categorical_crossentropy',
              metrics=['accuracy'])

model.fit(X_train,y_train,epochs=50)

accuracy=model.evaluate(X_test,y_test)[1]*100

print(f"\n Accuracy: {accuracy:.2f}%")
