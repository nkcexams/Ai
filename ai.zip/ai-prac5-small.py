import pandas as pd
from pgmpy.estimators import MaximumLikelihoodEstimator
from pgmpy.models import BayesianNetwork
from pgmpy.inference import VariableElimination

data=pd.read_csv("ds4.csv")

model=BayesianNetwork([('age','Lifestyle'),('Gender','Lifestyle'),('Family','heartdisease'),
                       ('diet','cholestrol'),('Lifestyle','diet'),('cholestrol','heartdisease')])
model.fit(data,estimator=MaximumLikelihoodEstimator)

infer=VariableElimination(model)

evidence = {
    'age': int(input('Age (SuperSenior:0, Senior:1, MiddleAged:2, Youth:3, Teen:4): ')),
    'Gender': int(input('Gender (Male:0, Female:1): ')),
    'Family': int(input('Family History (Yes:1, No:0): ')),
    'diet': int(input('Diet (High:0, Medium:1): ')),
    'Lifestyle': int(input('Lifestyle (Athlete:0, Active:1, Moderate:2, Sedentary:3): ')),
    'cholestrol': int(input('Cholesterol (High:0, BorderLine:1, Normal:2): '))
}


print(infer.query(variables=['heartdisease'],evidence=evidence))
