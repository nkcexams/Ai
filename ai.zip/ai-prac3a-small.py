VARIABLES = ["A", "B", "C", "D", "E", "F", "G"]
CONSTRAINTS = [("A", "B"), ("A", "C"), ("B", "C"), ("B", "D"), 
               ("B", "E"), ("C", "E"), ("C", "F"), ("D", "E"), 
               ("E", "F"), ("E", "G"), ("F", "G")]

def backtrack(assignment):
    if len(assignment) == len(VARIABLES):
        return assignment
    var=next(v for v in VARIABLES if v not in assignment)

    for value in["MONDAY","TUESDAY","WEDNESDAY"]:
        new_assignment = assignment.copy()
        new_assignment[var]= value

        if all(new_assignment.get(x) != new_assignment.get(y)for x,y in CONSTRAINTS if x in new_assignment and y in new_assignment):
            result= backtrack(new_assignment)
            if result is not None:
                return result
    return None

solution=backtrack({})
print(solution)
